package msa.msa_discovery;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsaDiscoveryApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsaDiscoveryApplication.class, args);
	}

}
